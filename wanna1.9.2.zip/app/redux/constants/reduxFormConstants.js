export const INIT = 'INIT';
export const CLEAR = 'CLEAR';
