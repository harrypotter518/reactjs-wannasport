module.exports = {
  name: 'WANNASPORT',
  desc: 'WANNASPORT - React.js Fullstack Project',
  prefix: 'wanna',
  footerText: 'WannaSport All Rights Reserved 2021',
  logoText: 'WannaSport',
};
