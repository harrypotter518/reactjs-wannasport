const guideSteps = [
  {
    title: 'Welcome to WannaSport',
    label: 'You can create Activity on Sports.',
    imgPath: '/images/guide/guide1.jpg',
  },
  {
    title: 'Dark and Light Mode',
    label: 'Enjoy your eyes with dark/light mode, just switch the option in theme panel or on header.',
    imgPath: '/images/guide/guide2.png',
  }

];

export default guideSteps;
